package com.polarlight.commons.basenio.exception;

public class HandlerNoDefineException extends Exception {
	
	private static final long serialVersionUID = -1393029602989298971L;

	public HandlerNoDefineException() {
		// TODO Auto-generated constructor stub
	}

	public HandlerNoDefineException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public HandlerNoDefineException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public HandlerNoDefineException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
