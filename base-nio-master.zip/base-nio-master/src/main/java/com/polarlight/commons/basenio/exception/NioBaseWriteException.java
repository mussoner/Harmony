package com.polarlight.commons.basenio.exception;

public class NioBaseWriteException extends Exception {

	private static final long serialVersionUID = -5877721119343582763L;

	public NioBaseWriteException() {
		// TODO Auto-generated constructor stub
	}

	public NioBaseWriteException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NioBaseWriteException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public NioBaseWriteException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
