package com.polarlight.commons.basenio.exception;

public class ProcessorPoolException extends Exception {

	private static final long serialVersionUID = 4907300233311257207L;

	public ProcessorPoolException() {
		// TODO Auto-generated constructor stub
	}

	public ProcessorPoolException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ProcessorPoolException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ProcessorPoolException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
}