package com.polarlight.commons.basenio.exception;

/**
 * 
 * @author DJ
 * @since 2.0
 */
public class UdpSessionModeException extends Exception {

	private static final long serialVersionUID = 6348339219356927932L;

	public UdpSessionModeException() {
		// TODO Auto-generated constructor stub
	}

	public UdpSessionModeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UdpSessionModeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public UdpSessionModeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
}