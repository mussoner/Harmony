package com.polarlight.commons.basenio.exception;

public class ConnectorException extends Exception {

	private static final long serialVersionUID = 8324405151794994830L;

	public ConnectorException() {
		// TODO Auto-generated constructor stub
	}

	public ConnectorException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ConnectorException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ConnectorException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
}
